export interface ICategory{
    id:number;
    Name:string;
    Description:string;
}
