export interface IProduct{
    id:number;
    productName:string;
    productQuantity:number;
    productPrice:number;
    productDescription:string;
    productImage:string;
    categoryId:number;
}